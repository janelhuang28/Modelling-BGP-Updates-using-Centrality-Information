class AP_Tuple:
    def __init__(self, node, depth, root):
        self.node = node
        self.depth = depth
        self.parent = root
