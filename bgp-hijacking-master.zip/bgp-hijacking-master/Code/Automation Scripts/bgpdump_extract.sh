
datafolder="soxrs"
# dataset=$datafolder"/ribs" # Directory
directorydata="processed"
# for entry in $dataset/*
# do
#
#   fileName=${entry/$dataset/""}
#   fileName=${fileName/"/"/""}
#   fileName=${fileName/".bz2"/""}
#   fileNamePath=$dataset"/"$fileName
#   newFileName=$fileName".txt"
#   echo "$newFileName"
#   bzip2 -d $entry
#   bgpdump $fileNamePath > $datafolder/$directorydata/$newFileName
# done
echo "$datafolder/$directorydata"
# find "$datafolder/$directorydata" -name 'rib*' | zip ribs.zip -@
scp -r ribs.zip huangjane@barretts.ecs.vuw.ac.nz:/home/huangjane

# dataset=$datafolder"/updates" # Directory
directorydata="processed"
# for entry in $dataset/*
# do
#
#   fileName=${entry/$dataset/""}
#   fileName=${fileName/"/"/""}
#   fileName=${fileName/".bz2"/""}
#   newFileName=$fileName".txt"
#   fileNamePath=$dataset"/"$fileName
#   echo "$newFileName"
#   echo "$newFileName"
#   bzip2 -d $entry
#   bgpdump $fileNamePath > $datafolder/$directorydata/$newFileName
# done
# echo "$datafolder/$directorydata"
# find "$datafolder/$directorydata" -name 'updates*' | zip updates.zip -@
# scp -r updates.zip huangjane@barretts.ecs.vuw.ac.nz:/home/huangjane
