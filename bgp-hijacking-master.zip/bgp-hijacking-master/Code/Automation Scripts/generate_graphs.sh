#!/bin/bash
# Normal
# Declare a string array with type
# declare -a StringArray=("20-08-30_18_19" )
#
# # Read the array values with space
# for val in "${StringArray[@]}"; do
#   echo $val
#   python main.py "$val" Normal
# done

# Abnormal
# Declare a string array with type
# declare -a StringArray=("20-08-28_12_19" "20-08-28_15_19" "20-08-28_18_19" "20-08-29_00_19" )
#
# # Read the array values with space
# for val in "${StringArray[@]}"; do
#   echo $val
#   python main.py "$val" "Normal"
# done

dataset="bviews" # Directory
for entry in $dataset/*
do

  fileName=${entry/$dataset/""}
  fileName=${fileName/"/"/""}
  fileName=${fileName/"grt.rib."/""}
  fileName=${fileName/".txt"/""}
  echo "$entry"
  echo "$fileName"
  python main.py "$fileName" entire_network normal
done
