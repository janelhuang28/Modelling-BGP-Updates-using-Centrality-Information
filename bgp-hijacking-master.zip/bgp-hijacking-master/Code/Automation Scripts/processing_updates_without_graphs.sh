#!/bin/bash
dataset="data" # Directory
for entry in $dataset/*
do

  fileName=${entry/$dataset/""}
  fileName=${fileName/"/"/""}
  fileName=${fileName/"rib"/""}
  fileName=${fileName/".txt"/""}
  echo "$entry"
  echo "$fileName"
  python main2.py "$fileName" entire_network normal
done
