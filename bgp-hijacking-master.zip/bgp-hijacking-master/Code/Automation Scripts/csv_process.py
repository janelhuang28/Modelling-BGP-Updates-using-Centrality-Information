import pandas as pd
import sys


def process_one_csv():
    data_file = sys.argv[1]
    csv_data = pd.read_csv(data_file, delimiter=",")
    to_remove_cols = []
    # count = 0
    for col in csv_data.columns:
        print(csv_data[col])
        column_items = csv_data[col].astype(str).str.match('-').sum()
        if column_items > 0:
            to_remove_cols.append(col)
            # if count == 1:
            #     break
            # count += 1
    for to_remove_col in to_remove_cols:
        print("dropped")
        del csv_data[to_remove_col]
    del csv_data['Column2549']
    print(csv_data)
    csv_data.to_csv('soxrs_' + data_file, index = False)

# Main Functions
def main():
    if len(sys.argv) <= 1:
        process_one_csv()
    else:
        process_multiple_csvs()

def remove_cols(data_file, to_remove_cols):
    csv_data = pd.read_csv(data_file, delimiter=",")
    for to_remove_col in to_remove_cols:
        if to_remove_col in csv_data.columns:
            del csv_data[to_remove_col]
    # del csv_data['Column2549']
    print(csv_data)
    csv_data.to_csv('soxrs_' + data_file, index = False)

def process_multiple_csvs():
    file_1 = sys.argv[1]
    file_2 = sys.argv[2] # Put smaller one here
    to_remove_cols = set()
    to_remove_cols = process_one_csv_multiple(file_1, to_remove_cols)
    to_remove_cols = process_one_csv_multiple(file_2, to_remove_cols)
    remove_cols(file_1, to_remove_cols)
    remove_cols(file_2, to_remove_cols)
    # for to_remove_col in to_remove_cols:
    #     del
    #     del csv_data[to_remove_col]
    # del csv_data['Column2549']
    # print(csv_data)
    # csv_data.to_csv('soxrs_' + data_file, index = False)
    # csv_data_1 = pd.read_csv(file_1, delimiter=",")
    # csv_data_2 = pd.read_csv(file_2, delimiter=",")
    # larger_csv = csv_data_2
    # larger_csv_file_name = file_2
    # smaller_csv = csv_data_1
    # print(csv_data_1)
    # if len(csv_data_1.columns) > len(csv_data_2.columns):
    #     larger_csv = csv_data_1
    #     larger_csv_file_name = file_1
    #     smaller_csv = csv_data_2
    # print(larger_csv_file_name)
    # to_remove = []
    # for col in larger_csv.columns:
    #     if col not in smaller_csv.columns:
    #         to_remove.append(col)
    # for to_remove_col in to_remove:
    #     del larger_csv[to_remove_col]
    # larger_csv.to_csv('soxrs_larger_' + larger_csv_file_name, index = False )
    # print(larger_csv)

def process_one_csv_multiple(data_file, to_remove_cols):
    print(data_file)
    csv_data = pd.read_csv(data_file, delimiter=",")
    for col in csv_data.columns:
        print(csv_data[col])
        column_items = csv_data[col].astype(str).str.match('-').sum()
        if column_items > 0:
            to_remove_cols.add(col)

    to_remove_cols.add('Column2549')
    return to_remove_cols

if __name__ == "__main__":
    main()
