The processing updates script generates the features e.g. centrality values based on the generated graphs.

The generation graphs script generates the graphs given a bview and an update file.
