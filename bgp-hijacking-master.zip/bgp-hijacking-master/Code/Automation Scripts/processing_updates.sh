#!/bin/bash

# dataset="Normal_Graphs/updates" # Directory
# for entry in $dataset/*
# do
#
#   fileName=${entry/$dataset/""}
#   fileName=${fileName/"/"/""}
#   echo "$entry"
#   echo "$fileName"
#   python main_feature.py "$entry" entire_network normal "$fileName"
# done
#
#
#
# dataset="Abnormal_Graphs/updates" # Directory
# for entry in $dataset/*
# do
#
#   fileName=${entry/$dataset/""}
#   fileName=${fileName/"/"/""}
#   echo "$fileName"
#   python main_feature.py "$entry" entire_network abnormal "$fileName"
# done
dataset="bviews" # Directory
for entry in $dataset/*
do

  fileName=${entry/$dataset/""}
  fileName=${fileName/"/"/""}
  fileName=${fileName/"grt.rib."/""}
  fileName=${fileName/".txt"/""}
  echo "$entry"
  echo "$fileName"
  python main2.py "$fileName" entire_network normal
done
