import httplib2
from bs4 import BeautifulSoup, SoupStrainer
import requests
import os
import gzip
import shutil
from contextlib import closing
import requests, zipfile, io

http = httplib2.Http()
type_to_download = "ribs"
type_to_download_caps = "UPDATES"
if type_to_download == "ribs":
    type_to_download_caps = "RIBS"
base_url = 'http://archive.routeviews.org/route-views.soxrs/bgpdata/2020.08/' + type_to_download_caps + '/' #linx sg
status, response = http.request(base_url)
save_path = "soxrs/" + type_to_download + "/"
if type_to_download == "ribs":
    type_to_download = "rib"
for link in BeautifulSoup(response, 'html.parser', parse_only=SoupStrainer('a')):
    if link.has_attr('href'):
	    # if type_to_download + ".20200826" in link['href'] or type_to_download + ".20200827" in link['href'] or type_to_download + ".20200828" in link['href'] or type_to_download + ".20200829" in link['href']:
    	if type_to_download + ".2020083" in link['href']:
        # if type_to_download + ".20200901" in link['href'] or type_to_download + ".20200902" in link['href']:
        	print(link['href'])
    		try:
    		    r = requests.get(base_url + link['href'])           #write file
    		    with open(save_path+link['href'], 'wb') as f:
    		        f.write(r.content)
    		        print('written')
    		    # with gzip.open(save_path + link['href'], 'rb') as f_in:           #unzip file
    		    #    with open(save_path + link['href'][:-4], 'wb') as f_out:
    		    #        shutil.copyfileobj(f_in, f_out)
    		    #        print("Copied")
    		    # os.remove(save_path+link['href'])         #delete zip file

    		except:
    		    print("Cannot open!")
    		    pass
