# Meeting Minutes

<p>
<details>

<summary><h2>Week 1</h2></summary>

Agenda
* Discussion on proposal and background reading

</details>
<details>

<summary><h2>Week 2</h2></summary>

Achieved
* Draft write up of proposal and background reading for task 1 achieved.

Next Steps
* Determining a suitable graphing tool
* Process BGP updates to form a graphical textual view

</details>
<details>

<summary><h2>Week 2</h2></summary>

Achieved
* Surveyed graphing tools such as BGPlay and BGP visualization.
* Created own graphing tool using Java

Next Steps
* Need to process announcements and withdrawals

</details>
<details>

<summary><h2>Week 3</h2></summary>

Achieved
* Processed announcements and withdrawals
* Finialised project proposal
* Processed data to produce a graphical view of data

Next Steps
* Generate table summary of BGP surveying methods

</details>
<details>

<summary><h2>Week 4</h2></summary>

Achieved
* Generated table summary
* Processed data

Next Steps
* Process announcments and withdrawals

</details>
<details>

<summary><h2>Week 4</h2></summary>

Achieved
* Processed announcments and withdrawals

Next Steps
* Get matrix feature

</details>
<details>

<summary><h2>Week 4</h2></summary>

Achieved
* Implemented articulation points algorithm to find features
* Implemented trie structure for storing prefixes
* Found matrix for articulation points

Next Steps
* Survey features such as centrality

</details>
<details>

<summary><h2>Week 5</h2></summary>

Achieved
* Implemented degree, closeness and betweeness centralities

Next Steps
* Find suitable machine learning algorithm

</details>
<details>

<summary><h2>Week 6</h2></summary>

Achieved
* Implemented Autoencoders

Next Steps
* Need to find threshold and optimise paramteres used in the autoencoders

</details>
<details>

<summary><h2>Break</h2></summary>

Achieved
* Processed dataset to find centralities

Next Steps
* Need to process data in correct format to be passed into autoencoder
* Generate a subset of network
* Adjust autoencoder parameters

</details>
<details>

<summary><h2>Week 7</h2></summary>

Achieved
* Achieved detection of anomalies using closeness centrality

Next Steps
* Find degree centrality anomalies
* Use Gaussian method to find anomalies
* Generate a grayscale image to map out anomalies

</details>
<details>

<summary><h2>Week 8</h2></summary>

Achieved
* Generated grayscale image
* Found degree centrality anomalies
* Used Gaussian method to find anomalies

Next Steps
* Find degree centrality for Gaussian 
* Generate full image for centrality
* Tidy Implementation and draft evaluation

</details>
<details>

<summary><h2>Week 9</h2></summary>

Achieved
* Drafted final and prelim report
* Found the source of the anomaly

Next Steps
* Prepare for REANNZ Meeting Presentation
* Incoporate another core router's data

</details>
<details>

<summary><h2>Week 10</h2></summary>

Achieved
* Processed wide's data
* Finished draft prelim
* Drafted REANNZ presentation

Next Steps
* Fix minor changed on draft

</details>

<details>

<summary><h2>Week 1</h2></summary>

Achieved
* Generated all evaluation results

Next Steps
* Fix changes on graphs producted on evaluation results

</details>
<details>
<summary><h2>Week 2</h2></summary>

Achieved
* Fix changes on graphs producted on evaluation results

Next Steps
* Draft out report

</details>

<details>

<summary><h2>Week 3</h2></summary>

Achieved
* Draft out evaluation of report

Next Steps
* Draft out final report

</details>
<details>

<summary><h2>Week 4</h2></summary>

Achieved
* Draft out conclusions and recommendations

Next Steps
* Draft out final report

</details>
<details>

<summary><h2>Week 5</h2></summary>

Achieved
* Draft out final report

Next Steps
* Draft out final report
* work on paper

</details>
<details>

<summary><h2>Week 6</h2></summary>

Achieved
* Draft out paper
* Draft out final report

Next Steps
* Draft out paper with feedback

</details>
<details>
<summary><h2>Week 7</h2></summary>

Achieved
* Draft out paper
* Implemented full GMM

Next Steps
* Implement feedback on paper

</details>
<details>
<summary><h2>Week 8</h2></summary>

Achieved
* Draft out paper

Next Steps
* Paper draft with muru's feedback

</details>
<details>
<summary><h2>Week 9</h2></summary>

Achieved
* Implemented muru's feedback

Next Steps
* Implement final report feedback from winston

</details>

<details>
<summary><h2>Week 10</h2></summary>

Achieved
* Implemented final report feedback from winston

Next Steps
* Change minor revisions on final report

</details>

</details>

<details>
<summary><h2>Week 11</h2></summary>

Achieved
* Drafted out version 6 of the final report

Next Steps
* Change minor revisions on final report

</details>
</p>

