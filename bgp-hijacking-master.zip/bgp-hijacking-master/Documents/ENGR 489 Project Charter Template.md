# Modelling BGP Updates for Anomaly Detection using Machine Learning
## ENGR 489 Project (2021)

### Project Charter

**Project Start Date:** 05 March 2021<br>
**Project End Date:** 30 October 2021

#### Key Dates

| Name | Date | Deliverable |
| --- | --- | --- |
| Project Proposal | Week 4 Trimester 1 | Written proposal (plan) |
| Preliminary Report | Week 10 Trimester 1 | Written report |
| Final Report | Week 10 Trimester 2 | Written report |
| Presentation | Week 13 Trimester 2 | Oral presentation |


**Budget Information:** No budget is required for this project

**Project Manager:** Janel Huang

**Project Objectives:** This project aims to model the BGP updates from a core router to determine suitable features to be used in a machine learning algorithm to detect anomalies. The following objectives will be met in this project
1. Survey various methods used to detect BGP anomalies and various machine learning methods 
2. Build or use a graphing tool to map information and updates from a Global Routing Table (GRT) into a network graph 
3. Determine suitable features from the network graph and machine learning method to train a model for anomaly detection 
4. Determine a method to identify the type of anomaly or source of anomaly upon detection 
5. (Extra) Incorporate information from another core router’s GRT to improve the model 

#### Approach

*  Milestone 1: Tasks 1, 2 and 3 by the end of Trimester 1
*  Milestone 2: Tasks 4 and 5 by week 10 of Trimester 2

#### Roles and Responsibilities

| Name | Organisation | Role | Contact | Email |
| ---- | ------------ | ---- | ------- | ----- |
| Janel Huang | Engineering | Project Manager | 02040772529 | huangjane@myvuw.ac.nz |
| Winston Seah | ECS | Project Supervisor | 64 4 463 5233 | winston.seah@ecs.vuw.ac.nz |
| Marcus Frean | ECS | Project Supervisor | - | marcus.frean@ecs.vuw.ac.nz |
| Murugaraj Odiathevar | ECS | Mentor | - | mururaj10@ecs.vuw.ac.nz |

